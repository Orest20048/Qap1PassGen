18/09/2024
Author: Orest Demchuk
PasswordGen
Description of app :
The Password Generator CLI is a command-line tool that generates secure passwords of customizable lengths and complexity. The tool allows users to specify whether they want lowercase letters, numbers, capital letters, and/or symbols in their password, making it versatile and highly customizable. The app is simple to use with various flags to control password generation and helps users create strong passwords for enhanced security.
List of commands:
npm run - for running and start the app
npm start - for start generate a password
node index.js - alternative command for start generate a password if the start command doesn't work properly or don't work at all.
